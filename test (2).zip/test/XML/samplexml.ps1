# load XML file into local variable and cast as XML type.
$doc = [xml](Get-Content C:\Users\boonar\Desktop\XML\input_web.xml)

$doc.welcome-file-list.welcome-file                                   #echoes "I like applesauce"
$doc.welcome-file-list.welcome-file  = "LoginSR.jsp"  #replace inner text of <one> node

# create new node...
#$newNode = $doc.CreateElement("three")
#$newNode.set_InnerText("And don't you forget it!")

# ...and position it in the hierarchy
#$doc.root.AppendChild($newNode)

# write results to disk
$doc.save("C:\Users\boonar\Desktop\XML\output_web.xml")