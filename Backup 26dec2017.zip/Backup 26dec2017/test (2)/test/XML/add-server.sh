#add-server.sh
#!/bin/bash

readonly JBOSS_HOME=/opt/jboss-eap-6
readonly INSTANCE_ID=1
readonly PORT_OFFSET=100
readonly SERVER_GROUP=${SERVER_GROUP:-'main'}

xlstproc --stringparam server-name "server${INSTANCE_ID}" 
         --stringparam server-group "${SERVER_GROUP}" 
         --stringparam port-shift "${PORT_OFFSET}"
         add-server.xsl 
         "${JBOSS_HOME}domain/configuration/host.xml" 