set echo on 
spool C:\Users\SVCT-WI-Jenkins\Desktop\Scripts_for_ORF2\Input_File_For_Deployment\DB_Scripts\sql_profile_check_script.lst

show user
show parameter db_name

SELECT PROFILE FROM ba_profiles;

spool off

exit;