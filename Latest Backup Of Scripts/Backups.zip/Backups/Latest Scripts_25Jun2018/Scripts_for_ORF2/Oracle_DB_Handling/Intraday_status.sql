spool C:\Users\SVCT-WI-Jenkins\Desktop\Scripts_for_ORF2\Oracle_DB_Handling\Intraday_status.lst;

select 
trigger_state
from QRTZONE_TRIGGERS;

commit;

spool off;