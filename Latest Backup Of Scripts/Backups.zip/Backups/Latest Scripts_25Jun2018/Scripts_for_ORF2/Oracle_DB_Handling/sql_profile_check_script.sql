spool C:\Users\SVCT-WI-Jenkins\Desktop\Scripts_for_ORF2\Oracle_DB_Handling\sql_profile_check_script.lst;

-- set echo on;

show user
show parameter db_name

SELECT PROFILE FROM ba_profiles;

-- set echo off;

spool off;

exit;