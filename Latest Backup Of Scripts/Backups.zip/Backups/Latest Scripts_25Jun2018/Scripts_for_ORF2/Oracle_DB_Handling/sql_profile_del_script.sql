spool C:\Users\SVCT-WI-Jenkins\Desktop\Scripts_for_ORF2\Oracle_DB_Handling\sql_profile_del_script.lst;

-- set echo on;

show user
show parameter db_name

DELETE FROM ba_xml where property_id in (select property_id from ba_properties where submod_id in (select submod_id FROM ba_submodules where mod_id in (select mod_id from ba_modules where PROFILE_ID in (select PROFILE_id from ba_profiles where PROFILE='INTRANET'))));
DELETE FROM ba_properties where submod_id in (select submod_id FROM ba_submodules where mod_id in (select mod_id from ba_modules where PROFILE_ID in (select PROFILE_id from ba_profiles where PROFILE='INTRANET')));
DELETE FROM ba_submodules where mod_id in (select mod_id from ba_modules where PROFILE_ID in (select PROFILE_id from ba_profiles where PROFILE='INTRANET'));
DELETE FROM ba_modules WHERE PROFILE_id IN (SELECT PROFILE_id FROM ba_profiles WHERE PROFILE='INTRANET');
DELETE FROM ba_profiles where PROFILE='INTRANET';

SELECT PROFILE FROM ba_profiles;

-- set echo off;

spool off;

exit;