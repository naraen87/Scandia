spool C:\Users\SVCT-WI-Jenkins\Desktop\Scripts_for_ORF2\Oracle_DB_Handling\Intradaybatchjob_status.lst;

SELECT b.job_name,c.string_val,
to_char(a.create_time, 'dd-mm-yyyy HH24:MI:SS') create_time,
to_char(a.START_TIME, 'dd-mm-yyyy HH24:MI:SS') start_time,
to_char(a.END_TIME, 'dd-mm-yyyy HH24:MI:SS') end_time ,
a.job_execution_id,a.job_instance_id, a.status,
a.exit_code,
a.exit_message,Extract(hour FROM(a.END_TIME- a.START_TIME)) || ' Hrs ' || 
Extract(minute FROM(a.END_TIME- a.START_TIME)) || ' Mins ' || Floor(Extract(second FROM(a.END_TIME- a.START_TIME)))|| ' Secs ' AS DURATION
FROM bancsdb.batch_job_execution a,bancsdb.batch_job_instance b, batch_job_execution_params c
WHERE a.job_instance_id=b.job_instance_id and a.job_execution_id=c.job_execution_id and (c.key_name='entity.code' or b.job_name='EODJob_regular' or 
b.job_name='jobBODReport' or b.job_name='EOQJob' or b.job_name='jobBODDateFlip')
AND a.end_time is null
order by a.job_execution_id desc;

commit;

spool off;